import 'package:flutter/material.dart';
import 'package:loginprogect/login.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    initialRoute: 'loginPage',
    routes: {'loginPage': (context) => MyLoginPage()},
  ));
}
